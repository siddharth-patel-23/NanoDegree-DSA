Problem_1 (sqrt):
The implementation relies on dividing the search space in two parts and checking at each 
time if the mid point power of 2 is bigger or smaller than the given number. The number is 
divided every time by 2 and checked after squaring. After we get a number less, then we check 
until it becomes greater. Hence, returning the number-1.

Time and Space Complexity:
The time complexity of the problem is O(logn) as we divide our no. by 2 every time and then
it takes some constant time to reach the resulting sqrt of our number.
There is no extra space required for the operation rather than O(1). Resulting the space complexity
to be O(1).


Problem_2:
Here first the sorted part of the array is checked and then in the unsorted part. This is done 
recursively. We use more divide approach, rather than computationally expensive on previous 
levels to spare some division. It increases our complexity slightly.

Time and Space Complexity:
The time complexity being an algorithm based on binary search is O(log(n)). The number of 
iterations we perform, i.e. recursive depth, follows the rule of recursive_depth^2 = n. Thus if 
we isolate the number of iterations in relation to the input space (n), we obtain log(n) = recursive_depth. 
As for the space complexity, it is independent of the input, requiring solely pointers to different array locations; O(1).


Problem_3:
This problem, as stated to be solved in time complexity of O(n*log(n)), has given the clue to be tackled by 
a variation of the merge sort algorithm. Indeed, it is a merge sort algorithm, except for the particular 
treatment if gives to the comparison of results coming from the previous recursion, if we are on the first 
level of the recursion. In this case, it does the comparison, as usual, but then starts saving the results on 
alternative lists, which are then returned as the results.

The usage of this alternative list saving is due to the fact that having the list perfectly sorted, if we start 
from the index[0] and give alternatively a value to each list, occupying this value an increasing digit position, 
we always obtain a combination that satisfies the condition of having a maximum sum of two numbers and maximum a 
digit of difference between them.

Time and Space Complexity:
As the base of the algorithm is the merge sort, having a time complexity of O(n*log(n)), and there have been no 
substantial modifications to the algorithm; just the addition of O(1) operations, the time complexity remains 
equal. As for the space complexity, if we hold the assumption that python gets automatically rid of each previous 
step auxiliary created arrays, then the space complexity is of O(n) (we have always arrays that amount to the length 
of the input array).


Problem_4:
The problem is much easier if extra space can be used, but to do in a single traverse within the same array was a real 
challenge, as there were different pointers (or variables) to be used and also the edge cases were taken care off.

Time and Space Complexity:
The time complexity is O(n) as we traverse the array and additionaly the complexity is precise as the array is traversed 
only once.
Space complexity is O(1), as no auxiliary space were used of more than O(1). i.e. Pointers or Variables


Problem_5:
This problem is focused on the development of the of a trie a data structure derived from a tree, suited for a 
good ratio between time and space complexity.

Time and Space Complexity:
For the trie, time complexity of searching and inserting from a trie depends on the length of the word a that’s 
being searched for, inserted, and the number of total words, n, making the runtime of these operations O(a*n). 
Looking into the space complexity of a trie, the worst case, would be when we have a word (or words), with no 
common characters between them, hence having, a node for each letter. Resulting in a space complexity of O(n).


Problem_6:
To find the min and max values of an unsorted array, I used to variables and assigned the 0-index values to them.
In a single traversal compared the values with the other array elements resulting in our answers.

Time and Space Complexity:
Time Complexity is O(n), as the result of single traversal.
Space Complexity is O(1), due to the fact that only 2 variables(extra) are used.


Problem_7:
It is similar to problem 5, except for the edge cases, like "root handler", and 
working with a hierarchy of web pages instead of strings. This problem is focused on 
the development of the of a trie a data structure derived from a tree, suited for a 
good ratio between time and space complexity.

Time and Space Complexity:
For the trie, time complexity of searching and inserting from a trie depends on the length of the 
path n that’s being searched for, inserted, making the runtime of these operations O(n). Looking 
into the space complexity of a trie, the worst case, would be when we have a path (or paths), with 
no common folders between them, hence having, a node for each path block (path between forward slashes). 
Resulting in a space complexity of O(n).

