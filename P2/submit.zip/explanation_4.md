Problem_4:
The problem is much easier if extra space can be used, but to do in a single traverse within the same array was a real 
challenge, as there were different pointers (or variables) to be used and also the edge cases were taken care off.

Time and Space Complexity:
The time complexity is O(n) as we traverse the array and additionaly the complexity is precise as the array is traversed 
only once.
Space complexity is O(1), as no auxiliary space were used of more than O(1). i.e. Pointers or Variables
