Problem_6:
To find the min and max values of an unsorted array, I used to variables and assigned the 0-index values to them.
In a single traversal compared the values with the other array elements resulting in our answers.

Time and Space Complexity:
Time Complexity is O(n), as the result of single traversal.
Space Complexity is O(1), due to the fact that only 2 variables(extra) are used.
